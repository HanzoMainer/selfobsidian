import { defineCollection } from "astro:content";
import { z } from "astro/zod";

export const collections = {
    notes: defineCollection({
        schema: z.object({
            title: z.string(),
            date: z.coerce.date(),
            tags: z.array(z.string()).default([]),
            draft: z.boolean().default(false),
        }),
    }),
};
